import React from 'react';

const TaskContext = React.createContext();
const ColumnContext = React.createContext();

export { TaskContext, ColumnContext};